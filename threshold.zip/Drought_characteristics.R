# Script to calculate average & maximum drought characteristics
#
#
# Anne van Loon
# University of Birmingham
#
# 10.05.2016
#
#####################################################################

rm(list=ls())
#setwd("...")

### read data
droughtfile=read.table("....txt",header=TRUE,sep='\t')

# EXAMPLE: can be done on pooled/unpooled droughts, with minor droughts in/out
droughtfile=read.table("droughts_minor_P.txt",header=TRUE,sep=' ')
droughtfile=read.table("droughts_minor_Q.txt",header=TRUE,sep=' ')

### load pooling functions
source("Characteristics_functions.R")

## calculate average & max drought characteristics
avg=Average(...,...,...)
avg=Average(droughtfile$dur,droughtfile$def,droughtfile$maxint)

max=Maximum(...,...,...)
max=Maximum(droughtfile$dur,droughtfile$def,droughtfile$maxint)


## write file
write.table(droughts,"....txt")
write.table(data.frame(avg,max),"droughts_char_P.txt")
write.table(data.frame(avg,max),"droughts_char_Q.txt")
