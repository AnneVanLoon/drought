# Script to calculate a fixed or variable threshold and write to file 
#
#
# Anne van Loon
# University of Birmingham
#
# 10.05.2016
#
#####################################################################

rm(list=ls())
#setwd("...")

### read data
datafile  = read.table("....txt",header=TRUE,sep='\t')  # read in data
dates		  = as.Date(datafile$...,format="%Y-%m-%d")	    # get dates from data
var       = ...                                         # variable to use in analysis

# EXAMPLE
datafile 	= read.table("Guadiana_60-80.txt", header=TRUE, sep = "\t") # you can use the same timeseries from which you will calculate the drought characteristics or a different one
dates		  = as.Date(datafile$date.yyyymmdd,format="%Y-%m-%d")	
var       = filter(datafile$Psim, rep(1/10,10),sides=2)   # for precipitation (or other variables) a moving average can be applied, in this case 10days   
var       = datafile$Qobs  # discharge, you can use more than one variable
var       = datafile$SLZ  # groundwater, note that for state variables maximum intensty is used instead of deficit volume

Jdays = strptime(dates,format="%Y-%m-%d")$yday+1  	# extract Julian days from dates

### load threshold functions
source("Threshold_functions.R")

### calculate fixed and/or varibale threshold
# FixThres: fixed threshold
# VarThres: variable threshold based on 30d moving window
# "data" = data variable, "percentile" = percentile of FDC (exceedance), "dates" = date variable, "Jdays" = Julian days
threshold=FixThres(var,...,dates)
threshold=VarThres(var,...,dates,Jdays)

# EXAMPLE
threshold=FixThres(var,0.8,dates)   # 0.8 = 80th percentile, 0.95 = 95th percentile
threshold=VarThres(var,0.8,dates,Jdays)

### write file
write.table(threshold,"....txt")

# EXAMPLE
write.table(threshold,"fixed_threshold.txt")
write.table(threshold,"variable_threshold_P.txt")
write.table(threshold,"variable_threshold_Q.txt")
