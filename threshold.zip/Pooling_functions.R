## Functions to pool droughts and remove minor droughts  
## Pooling: "st" = drought starting date variable, "dur" = drought duration variable, 
##          "def" = drought deficit variable, "maxint" = maximum intensity variable, "IT" = interevent time period 
## Minor: "file" = data variable, "dur" = drought duration variable, "MIN" = minimum drought duration

Pooling <- function(st, dur, def, maxint, IT){
  start.date = as.Date(as.character(st),format="%Y-%m-%d")
  end.date = start.date + dur -1
  intereventtime = array()
  for(i in 1:length(dur)){
    intereventtime[i] = (start.date[i+1])-(end.date[i]+1)
  }
  intereventtime[length(dur)] = 999
  dur.pooled = array()
  def.pooled = array()
  maxint.pooled = array()
  st.pooled = array()
  end.pooled = array()
  duration = dur[1]
  deficit = def[1]
  maxintensity = maxint[1]
  begin = start.date[1]
  j=1
  for(i in 1:length(dur)){
    if (intereventtime[i] < IT){
      duration = duration + intereventtime[j] + dur[j+1]
      deficit = deficit + def[j+1]
      maxintensity = max(maxintensity, maxint[j+1])
      if (j == 1 || intereventtime[j-1] > IT) {
        begin = start.date[j]
      }
      j = j+1
    } else { 
      dur.pooled[i] = duration
      def.pooled[i] = deficit
      maxint.pooled[i] = maxintensity
      st.pooled[i] = begin
      j=i+1
      duration = dur[i+1]
      deficit = def[i+1]
      maxintensity = maxint[i+1]
      begin = start.date[i+1]
    }
  }
  st.pooled = as.Date(st.pooled,format="%Y-%m-%d",origin="1970-01-01")
  end.pooled = st.pooled + dur.pooled - 1
  end.pooled = as.Date(end.pooled,format="%Y-%m-%d",origin="1970-01-01")
  droughts.pooled = na.omit(data.frame(st.pooled,end.pooled,dur.pooled,def.pooled,maxint.pooled))
  row.names(droughts.pooled) <- 1:nrow(droughts.pooled)
  
  return(droughts.pooled)
}

Minor <- function(file, dur, MIN){
  droughts.sub <- subset(file, dur > 15) 
  row.names(droughts.sub) <- 1:nrow(droughts.sub)
  return(droughts.sub)
}
