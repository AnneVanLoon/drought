# Script to pool droughts & remove minor droughts
#
#
# Anne van Loon
# University of Birmingham
#
# 10.05.2016
#
#####################################################################

rm(list=ls())
#setwd("...")

### read data
droughtfile=read.table("....txt",header=TRUE,sep='\t')

#EXAMPLE
droughtfile=read.table("droughts_fixed.txt",header=TRUE,sep=' ')
droughtfile=read.table("droughts_variable_P.txt",header=TRUE,sep=' ')
droughtfile=read.table("droughts_variable_Q.txt",header=TRUE,sep=' ')

### load pooling functions
source("Pooling_functions.R")

### pooling droughts
## Pooling: "st" = drought starting date variable, "dur" = drought duration variable,   
##          "def" = drought deficit variable, "maxint" = maximum intensity variable, "IT" = interevent time period 
droughts=Pooling(...,...,...,...,...,...)

# EXAMPLE: interevent time period = 10 days
droughts=Pooling(droughtfile$st,droughtfile$dur,droughtfile$def,droughtfile$maxint,10)

## write file
write.table(droughts,"....txt")
write.table(droughts,"droughts_pooled_P.txt")
write.table(droughts,"droughts_pooled_Q.txt")

### removing minor droughts 
## subset of droughts with duration larger than x days
## Minor: "file" = data variable, "dur" = drought duration variable, "MIN" = minimum drought duration
droughts=Minor(...,...,...)

# EXAMPLE: min drought duration = 15
droughts=Minor(droughtfile,droughtfile$dur,15) # on unpooled droughts
droughts=Minor(droughts,droughts$dur,15) # on pooled droughts

## write file
write.table(droughts,"....txt")
write.table(droughts,"droughts_minor_P.txt")
write.table(droughts,"droughts_minor_Q.txt")
