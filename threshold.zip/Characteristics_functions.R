## Functions to pool droughts and remove minor droughts  
## "dur" = drought duration variable, "def" = drought deficit variable, "maxint" = maximum intensity variable

Average <- function(dur,def,maxint){
  avg.dur = mean(dur) 
  avg.def = mean(def)
  avg.maxint = mean(maxint)
  avg.droughts = data.frame(avg.dur,avg.def,avg.maxint)
  return(avg.droughts)
}

Maximum <- function(dur,def,maxint){
  max.dur = max(dur) 
  max.def = max(def)
  max.maxint = max(maxint)
  max.droughts = data.frame(max.dur,max.def,max.maxint)
  return(max.droughts)
}